import { useEffect, useState } from 'react'
import { getEmployees } from '../api/client'

// Fetches the employee list once and renders it as a dropdown.
// Parent page owns the selected value; this component only supplies options.
export default function EmployeeSelect({ value, onChange }) {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    getEmployees()
      .then((res) => setEmployees(res.data))
      .catch(() => setError('Could not load employees.'))
      .finally(() => setLoading(false))
  }, [])

  if (error) return <p className="text-sm text-reject">{error}</p>

  return (
    <select
      className="input max-w-xs"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={loading}
    >
      <option value="">{loading ? 'Loading employees…' : 'Select an employee'}</option>
      {employees.map((emp) => (
        <option key={emp.id} value={emp.id}>
          {emp.name} {emp.department ? `— ${emp.department}` : ''}
        </option>
      ))}
    </select>
  )
}
