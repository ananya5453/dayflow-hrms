import { NavLink } from 'react-router-dom'

const links = [
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/employees', label: 'Employees' },
  { to: '/leaves', label: 'Leave Approval' },
  { to: '/payroll', label: 'Payroll' },
]

export default function Sidebar() {
  return (
    <aside className="w-56 shrink-0 bg-ink text-white min-h-screen hidden md:flex flex-col">
      <div className="px-5 py-6 border-b border-white/10">
        <span className="font-display font-extrabold text-lg tracking-tight">Dayflow</span>
        <p className="text-xs text-white/50 mt-0.5">HR Admin</p>
      </div>
      <nav className="flex-1 px-3 py-4 space-y-1">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              `block rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                isActive ? 'bg-flow text-white' : 'text-white/70 hover:bg-ink2 hover:text-white'
              }`
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
