import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import Layout from '../components/Layout.jsx'
import LoadingSpinner from '../components/LoadingSpinner.jsx'
import EmployeeSelect from '../components/EmployeeSelect.jsx'
import { getPayroll, updatePayroll } from '../api/client'

const EMPTY_FORM = { basic_salary: '', allowances: '', deductions: '' }

export default function Payroll() {
  const [searchParams, setSearchParams] = useSearchParams()
  const employeeId = searchParams.get('employeeId') || ''

  const [form, setForm] = useState(EMPTY_FORM)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [formError, setFormError] = useState('')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!employeeId) {
      setForm(EMPTY_FORM)
      return
    }
    setLoading(true)
    setError('')
    setSaved(false)
    getPayroll(employeeId)
      .then((res) => {
        const data = res.data
        setForm({
          basic_salary: data.basic_salary ?? '',
          allowances: data.allowances ?? '',
          deductions: data.deductions ?? '',
        })
      })
      .catch(() => setError('Could not load payroll for this employee.'))
      .finally(() => setLoading(false))
  }, [employeeId])

  const net =
    (Number(form.basic_salary) || 0) + (Number(form.allowances) || 0) - (Number(form.deductions) || 0)

  function handleChange(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }))
    setSaved(false)
  }

  function validate() {
    for (const [field, value] of Object.entries(form)) {
      if (value === '' || value === null) return `Please fill in ${field.replace('_', ' ')}.`
      if (Number.isNaN(Number(value)) || Number(value) < 0) {
        return `${field.replace('_', ' ')} must be a non-negative number.`
      }
    }
    return ''
  }

  async function handleSave(e) {
    e.preventDefault()
    const validationError = validate()
    if (validationError) {
      setFormError(validationError)
      return
    }
    setFormError('')
    setSaving(true)
    try {
      await updatePayroll(employeeId, {
        basic_salary: Number(form.basic_salary),
        allowances: Number(form.allowances),
        deductions: Number(form.deductions),
      })
      setSaved(true)
    } catch {
      setFormError('Could not save changes. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Layout title="Payroll Management">
      <div className="mb-4">
        <label className="label">Employee</label>
        <EmployeeSelect
          value={employeeId}
          onChange={(id) => setSearchParams(id ? { employeeId: id } : {})}
        />
      </div>

      {loading && <LoadingSpinner label="Loading payroll…" />}
      {error && <p className="text-reject text-sm">{error}</p>}

      {!employeeId && !loading && (
        <p className="text-slate-400 text-sm">Select an employee to view or edit their payroll.</p>
      )}

      {employeeId && !loading && !error && (
        <form onSubmit={handleSave} className="card max-w-md space-y-4">
          {formError && (
            <div className="rounded-lg bg-rose-50 text-reject text-sm px-3 py-2">{formError}</div>
          )}
          {saved && (
            <div className="rounded-lg bg-emerald-50 text-approve text-sm px-3 py-2">
              Payroll updated successfully.
            </div>
          )}

          <div>
            <label className="label">Basic Salary</label>
            <input
              type="number"
              min="0"
              step="0.01"
              className="input"
              value={form.basic_salary}
              onChange={(e) => handleChange('basic_salary', e.target.value)}
            />
          </div>

          <div>
            <label className="label">Allowances</label>
            <input
              type="number"
              min="0"
              step="0.01"
              className="input"
              value={form.allowances}
              onChange={(e) => handleChange('allowances', e.target.value)}
            />
          </div>

          <div>
            <label className="label">Deductions</label>
            <input
              type="number"
              min="0"
              step="0.01"
              className="input"
              value={form.deductions}
              onChange={(e) => handleChange('deductions', e.target.value)}
            />
          </div>

          <div className="border-t border-slate-100 pt-3 flex items-center justify-between">
            <span className="text-sm text-slate-500">Net pay</span>
            <span className="font-bold text-lg font-display">{net.toFixed(2)}</span>
          </div>

          <button type="submit" className="btn-primary w-full" disabled={saving}>
            {saving ? 'Saving…' : 'Save changes'}
          </button>
        </form>
      )}
    </Layout>
  )
}
