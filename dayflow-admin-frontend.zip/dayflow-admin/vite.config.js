import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Standard Vite + React setup. No extra tooling added.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173
  }
})
