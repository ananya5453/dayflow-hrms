# Dayflow — Human Resource Management System

A hackathon-scoped HRMS with three parts:

```
dayflow-hrms/
├── backend/              Flask + SQLite API (all endpoints, both apps)
├── admin-frontend/        React app for Admin/HR
└── employee-frontend/     React app for regular employees
```

Both frontends talk to the one backend over plain REST + JWT. Nothing is
hardcoded — every screen in both apps reads and writes through the API.

## Run it (3 terminals)

**1. Backend**
```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python seed.py            # creates dayflow.db with demo accounts
python app.py              # http://localhost:5000
```

**2. Admin/HR frontend**
```bash
cd admin-frontend
npm install
cp .env.example .env       # VITE_API_BASE_URL=http://localhost:5000
npm run dev                 # http://localhost:5173
```

**3. Employee frontend**
```bash
cd employee-frontend
npm install
cp .env.example .env       # VITE_API_BASE_URL=http://localhost:5000
npm run dev                 # http://localhost:5174 (Vite will pick the next free port)
```

## Demo accounts

| Role     | Email                | Password       | Use with            |
|----------|-----------------------|----------------|----------------------|
| Admin    | admin@dayflow.com     | Admin@123      | admin-frontend        |
| HR       | hr@dayflow.com        | Hr@12345       | admin-frontend        |
| Employee | rohit@dayflow.com     | Employee@123   | employee-frontend     |
| Employee | neha@dayflow.com      | Employee@123   | employee-frontend     |
| Employee | karan@dayflow.com     | Employee@123   | employee-frontend     |

(Or use Sign Up in the employee app to create a fresh account.)

## The core workflow, end to end

1. Log into **employee-frontend** as `rohit@dayflow.com` → go to **Time Off**
   → submit a request. It's saved as `Pending`.
2. Log into **admin-frontend** as `hr@dayflow.com` → go to **Leave
   Approval** → the request appears → click Approve or Reject.
3. Back in the employee app, refresh **Time Off** → the status has updated.

This loop was tested directly against the API (not just eyeballed) — signup,
login, role rejection, self-profile-edit restrictions, check-in/out, leave
apply → approve, and payroll read/write were all exercised with curl before
handoff, so the contract between frontend and backend is confirmed correct.

## Role-based access, enforced server-side

- Only `admin`/`hr` tokens can list all employees, approve/reject leave, or
  write to payroll — checked in the backend, not just hidden in the UI.
- An `employee` token can only ever see and edit **its own** records; trying
  to view or edit another employee's data returns `403`.
- The `employee-frontend` login refuses `admin`/`hr` accounts (points them
  to the other app); `admin-frontend` login refuses plain `employee`
  accounts, matching the AuthContext logic already in the admin app.

## What's intentionally out of scope (hackathon-sized)

- Real email verification on signup (accounts are verified immediately)
- Password reset flow
- Refresh tokens (JWT is a flat 12-hour access token)
- File uploads for profile pictures (field exists, but it's a URL string,
  not a file upload endpoint)

These are the natural "future enhancements" the spec PDF calls out.
