# Dayflow HRMS — Backend (Flask + SQLite)

Implements every endpoint the two frontends need: auth, employee profiles,
attendance (with check-in/check-out), leave/time-off with approval workflow,
and payroll.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python seed.py                  # creates dayflow.db with demo accounts + sample data
python app.py                   # runs on http://localhost:5000
```

## Demo accounts (created by seed.py)

| Role     | Email                | Password       |
|----------|-----------------------|----------------|
| Admin    | admin@dayflow.com     | Admin@123      |
| HR       | hr@dayflow.com        | Hr@12345       |
| Employee | rohit@dayflow.com     | Employee@123   |
| Employee | neha@dayflow.com      | Employee@123   |
| Employee | karan@dayflow.com     | Employee@123   |

## Endpoints

**Auth**
- `POST /api/signup` — employee self-registration
- `POST /api/login` — returns `{ token, user }`
- `GET /api/me` — current user from token

**Employees**
- `GET /api/employees` — admin/hr only, supports `?q=` search
- `GET /api/employees/<id>` — admin/hr, or the employee themself
- `PUT /api/employees/<id>` — admin/hr can edit any field; an employee can
  only edit `phone`, `address`, `profile_picture` on their own record
- `GET /api/profile` — shortcut for "my own profile + payroll"

**Attendance**
- `GET /api/attendance/<employee_id>` — admin/hr, or the employee themself
- `POST /api/attendance/checkin` — self check-in for today
- `POST /api/attendance/checkout` — self check-out for today

**Leave / Time-off**
- `GET /api/leaves` — admin/hr sees everyone (optional `?employee_id=`,
  `?status=`); an employee only ever sees their own
- `POST /api/leaves` — employee applies (`leave_type`: Paid/Sick/Unpaid,
  `start_date`, `end_date`, `remarks`)
- `PUT /api/leaves/<id>/approve` — admin/hr only
- `PUT /api/leaves/<id>/reject` — admin/hr only

**Payroll**
- `GET /api/payroll/<employee_id>` — read-only for the employee themself,
  admin/hr can view anyone
- `PUT /api/payroll/<employee_id>` — admin/hr only, validates non-negative
  numbers

## Role enforcement

Every write and every sensitive read checks the `role` claim embedded in the
JWT at login time — an employee token physically cannot approve leave, edit
someone else's profile, or write to payroll; the API returns `403` before
touching the database. This is enforced server-side, not just hidden in the
UI, so it holds even if someone calls the API directly.

## Notes

- SQLite file (`dayflow.db`) is created automatically on first run.
- CORS is open to `http://localhost:5173` and `:5174` (both frontends' Vite
  dev server ports) — edit `CORS_ORIGINS` in `.env` for deployment.
- This is a hackathon-scoped build: no email verification, no password
  reset, no refresh tokens. Good enough to demo the full loop end to end.
