from datetime import datetime, date
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    employee_code = db.Column(db.String(20), unique=True, nullable=False)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="employee")  # admin | hr | employee
    phone = db.Column(db.String(30))
    department = db.Column(db.String(80))
    designation = db.Column(db.String(80))
    profile_picture = db.Column(db.String(255))
    address = db.Column(db.String(255))
    join_date = db.Column(db.Date, default=date.today)
    is_verified = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    attendance_records = db.relationship("Attendance", backref="employee", lazy=True,
                                          cascade="all, delete-orphan")
    leave_requests = db.relationship("Leave", backref="employee", lazy=True,
                                      foreign_keys="Leave.employee_id",
                                      cascade="all, delete-orphan")
    payroll = db.relationship("Payroll", backref="employee", uselist=False,
                               cascade="all, delete-orphan")

    def set_password(self, raw_password):
        self.password_hash = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password_hash, raw_password)

    def to_dict(self, include_sensitive=False):
        data = {
            "id": self.id,
            "employee_code": self.employee_code,
            "name": self.name,
            "email": self.email,
            "role": self.role,
            "phone": self.phone,
            "department": self.department,
            "designation": self.designation,
            "profile_picture": self.profile_picture,
            "address": self.address,
            "join_date": self.join_date.isoformat() if self.join_date else None,
        }
        return data


class Attendance(db.Model):
    __tablename__ = "attendance"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    date = db.Column(db.Date, nullable=False, default=date.today)
    check_in = db.Column(db.DateTime, nullable=True)
    check_out = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="Present")
    # Present | Absent | Half-day | Leave

    def to_dict(self):
        return {
            "id": self.id,
            "employee_id": self.employee_id,
            "date": self.date.isoformat(),
            "check_in": self.check_in.isoformat() if self.check_in else None,
            "check_out": self.check_out.isoformat() if self.check_out else None,
            "status": self.status,
        }


class Leave(db.Model):
    __tablename__ = "leaves"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    leave_type = db.Column(db.String(20), nullable=False)  # Paid | Sick | Unpaid
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    remarks = db.Column(db.String(500))
    status = db.Column(db.String(20), nullable=False, default="Pending")
    # Pending | Approved | Rejected
    admin_comment = db.Column(db.String(500))
    reviewed_by = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "employee_id": self.employee_id,
            "employee_name": self.employee.name if self.employee else None,
            "leave_type": self.leave_type,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "remarks": self.remarks,
            "status": self.status,
            "admin_comment": self.admin_comment,
            "created_at": self.created_at.isoformat(),
        }


class Payroll(db.Model):
    __tablename__ = "payroll"

    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    basic_salary = db.Column(db.Float, nullable=False, default=0)
    allowances = db.Column(db.Float, nullable=False, default=0)
    deductions = db.Column(db.Float, nullable=False, default=0)
    pay_frequency = db.Column(db.String(20), default="Monthly")
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @property
    def net_pay(self):
        return round((self.basic_salary or 0) + (self.allowances or 0) - (self.deductions or 0), 2)

    def to_dict(self):
        return {
            "id": self.id,
            "employee_id": self.employee_id,
            "basic_salary": self.basic_salary,
            "allowances": self.allowances,
            "deductions": self.deductions,
            "pay_frequency": self.pay_frequency,
            "net_pay": self.net_pay,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
