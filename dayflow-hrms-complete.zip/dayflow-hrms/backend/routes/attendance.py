from datetime import date, datetime
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt

from extensions import db
from models import Attendance
from auth_utils import is_admin_or_hr

attendance_bp = Blueprint("attendance", __name__, url_prefix="/api")


@attendance_bp.get("/attendance/<int:employee_id>")
@jwt_required()
def get_attendance(employee_id):
    claims = get_jwt()
    if not is_admin_or_hr(claims) and int(get_jwt_identity()) != employee_id:
        return jsonify({"error": "You can only view your own attendance."}), 403

    records = (
        Attendance.query.filter_by(employee_id=employee_id)
        .order_by(Attendance.date.desc())
        .all()
    )
    return jsonify([r.to_dict() for r in records])


@attendance_bp.post("/attendance/checkin")
@jwt_required()
def check_in():
    employee_id = int(get_jwt_identity())
    today = date.today()

    record = Attendance.query.filter_by(employee_id=employee_id, date=today).first()
    if record and record.check_in:
        return jsonify({"error": "You have already checked in today."}), 409

    if not record:
        record = Attendance(employee_id=employee_id, date=today, status="Present")
        db.session.add(record)

    record.check_in = datetime.utcnow()
    record.status = "Present"
    db.session.commit()
    return jsonify(record.to_dict()), 201


@attendance_bp.post("/attendance/checkout")
@jwt_required()
def check_out():
    employee_id = int(get_jwt_identity())
    today = date.today()

    record = Attendance.query.filter_by(employee_id=employee_id, date=today).first()
    if not record or not record.check_in:
        return jsonify({"error": "You need to check in before checking out."}), 400
    if record.check_out:
        return jsonify({"error": "You have already checked out today."}), 409

    record.check_out = datetime.utcnow()
    db.session.commit()
    return jsonify(record.to_dict())
