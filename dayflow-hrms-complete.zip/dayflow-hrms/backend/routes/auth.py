import re
from datetime import date
from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, get_jwt, jwt_required, get_jwt_identity

from extensions import db
from models import User, Payroll

auth_bp = Blueprint("auth", __name__, url_prefix="/api")

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


@auth_bp.post("/signup")
def signup():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""
    role = (data.get("role") or "employee").strip().lower()
    employee_code = (data.get("employee_id") or data.get("employee_code") or "").strip()

    if role not in ("employee", "hr", "admin"):
        role = "employee"

    errors = {}
    if not name:
        errors["name"] = "Name is required."
    if not EMAIL_RE.match(email):
        errors["email"] = "A valid email is required."
    if len(password) < 8:
        errors["password"] = "Password must be at least 8 characters."
    if not employee_code:
        errors["employee_id"] = "Employee ID is required."

    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "An account with this email already exists."}), 409
    if User.query.filter_by(employee_code=employee_code).first():
        return jsonify({"error": "This Employee ID is already registered."}), 409

    user = User(
        employee_code=employee_code,
        name=name,
        email=email,
        role=role,
        phone=data.get("phone"),
        department=data.get("department"),
        designation=data.get("designation"),
        join_date=date.today(),
        is_verified=True,  # simplified: no real email verification flow in this MVP
    )
    user.set_password(password)
    db.session.add(user)
    db.session.flush()

    db.session.add(Payroll(employee_id=user.id, basic_salary=0, allowances=0, deductions=0))
    db.session.commit()

    return jsonify({"message": "Account created. You can now log in.", "user": user.to_dict()}), 201


@auth_bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    email = (data.get("email") or "").strip().lower()
    password = data.get("password") or ""

    if not EMAIL_RE.match(email) or not password:
        return jsonify({"error": "Email and password are required."}), 400

    user = User.query.filter_by(email=email).first()
    if not user or not user.check_password(password):
        return jsonify({"error": "Invalid email or password."}), 401

    token = create_access_token(identity=str(user.id), additional_claims={"role": user.role})
    return jsonify({"token": token, "user": user.to_dict()}), 200


@auth_bp.get("/me")
@jwt_required()
def me():
    user = User.query.get_or_404(get_jwt_identity())
    return jsonify(user.to_dict())
