from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt

from extensions import db
from models import User, Payroll
from auth_utils import roles_required, is_admin_or_hr

employees_bp = Blueprint("employees", __name__, url_prefix="/api")

# Fields an employee is allowed to edit on their own profile.
SELF_EDITABLE_FIELDS = {"phone", "address", "profile_picture"}
# Additional fields an admin can edit on anyone's profile.
ADMIN_EDITABLE_FIELDS = SELF_EDITABLE_FIELDS | {
    "name", "department", "designation", "role", "employee_code",
}


@employees_bp.get("/employees")
@roles_required("admin", "hr")
def list_employees():
    q = (request.args.get("q") or "").strip().lower()
    query = User.query
    if q:
        like = f"%{q}%"
        query = query.filter(
            db.or_(User.name.ilike(like), User.email.ilike(like), User.department.ilike(like))
        )
    employees = query.order_by(User.name.asc()).all()
    return jsonify([e.to_dict() for e in employees])


@employees_bp.get("/employees/<int:employee_id>")
@jwt_required()
def get_employee(employee_id):
    claims = get_jwt()
    if not is_admin_or_hr(claims) and int(get_jwt_identity()) != employee_id:
        return jsonify({"error": "You can only view your own profile."}), 403
    user = User.query.get_or_404(employee_id)
    payload = user.to_dict()
    if is_admin_or_hr(claims) or int(get_jwt_identity()) == employee_id:
        payroll = Payroll.query.filter_by(employee_id=employee_id).first()
        payload["payroll"] = payroll.to_dict() if payroll else None
    return jsonify(payload)


@employees_bp.put("/employees/<int:employee_id>")
@jwt_required()
def update_employee(employee_id):
    claims = get_jwt()
    is_self = int(get_jwt_identity()) == employee_id
    is_privileged = is_admin_or_hr(claims)

    if not is_self and not is_privileged:
        return jsonify({"error": "You do not have permission to edit this profile."}), 403

    user = User.query.get_or_404(employee_id)
    data = request.get_json(silent=True) or {}

    allowed = ADMIN_EDITABLE_FIELDS if is_privileged else SELF_EDITABLE_FIELDS
    updates = {k: v for k, v in data.items() if k in allowed}

    if "role" in updates and updates["role"] not in ("admin", "hr", "employee"):
        return jsonify({"error": "Invalid role."}), 400

    for field, value in updates.items():
        setattr(user, field, value)

    db.session.commit()
    return jsonify(user.to_dict())


@employees_bp.get("/profile")
@jwt_required()
def my_profile():
    user = User.query.get_or_404(get_jwt_identity())
    payload = user.to_dict()
    payroll = Payroll.query.filter_by(employee_id=user.id).first()
    payload["payroll"] = payroll.to_dict() if payroll else None
    return jsonify(payload)
