from datetime import datetime, date
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt

from extensions import db
from models import Leave
from auth_utils import is_admin_or_hr

leaves_bp = Blueprint("leaves", __name__, url_prefix="/api")

VALID_TYPES = {"Paid", "Sick", "Unpaid"}


def _parse_date(value):
    return datetime.strptime(value, "%Y-%m-%d").date()


@leaves_bp.get("/leaves")
@jwt_required()
def list_leaves():
    claims = get_jwt()
    status = request.args.get("status")

    query = Leave.query
    if is_admin_or_hr(claims):
        employee_id = request.args.get("employee_id")
        if employee_id:
            query = query.filter_by(employee_id=employee_id)
    else:
        # Employees can only ever see their own requests.
        query = query.filter_by(employee_id=int(get_jwt_identity()))

    if status:
        query = query.filter_by(status=status)

    leaves = query.order_by(Leave.created_at.desc()).all()
    return jsonify([l.to_dict() for l in leaves])


@leaves_bp.post("/leaves")
@jwt_required()
def apply_leave():
    employee_id = int(get_jwt_identity())
    data = request.get_json(silent=True) or {}

    leave_type = data.get("leave_type")
    errors = {}
    if leave_type not in VALID_TYPES:
        errors["leave_type"] = "leave_type must be one of Paid, Sick, Unpaid."

    try:
        start = _parse_date(data.get("start_date", ""))
    except (ValueError, TypeError):
        errors["start_date"] = "start_date must be YYYY-MM-DD."
        start = None
    try:
        end = _parse_date(data.get("end_date", ""))
    except (ValueError, TypeError):
        errors["end_date"] = "end_date must be YYYY-MM-DD."
        end = None

    if start and end and end < start:
        errors["end_date"] = "End date cannot be before start date."

    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 400

    leave = Leave(
        employee_id=employee_id,
        leave_type=leave_type,
        start_date=start,
        end_date=end,
        remarks=(data.get("remarks") or "").strip(),
        status="Pending",
    )
    db.session.add(leave)
    db.session.commit()
    return jsonify(leave.to_dict()), 201


@leaves_bp.put("/leaves/<int:leave_id>/approve")
@jwt_required()
def approve_leave(leave_id):
    claims = get_jwt()
    if not is_admin_or_hr(claims):
        return jsonify({"error": "Only HR or Admin can approve leave requests."}), 403

    leave = Leave.query.get_or_404(leave_id)
    if leave.status != "Pending":
        return jsonify({"error": f"This request is already {leave.status.lower()}."}), 409

    data = request.get_json(silent=True) or {}
    leave.status = "Approved"
    leave.admin_comment = (data.get("comment") or "").strip() or None
    leave.reviewed_by = int(get_jwt_identity())
    db.session.commit()
    return jsonify(leave.to_dict())


@leaves_bp.put("/leaves/<int:leave_id>/reject")
@jwt_required()
def reject_leave(leave_id):
    claims = get_jwt()
    if not is_admin_or_hr(claims):
        return jsonify({"error": "Only HR or Admin can reject leave requests."}), 403

    leave = Leave.query.get_or_404(leave_id)
    if leave.status != "Pending":
        return jsonify({"error": f"This request is already {leave.status.lower()}."}), 409

    data = request.get_json(silent=True) or {}
    leave.status = "Rejected"
    leave.admin_comment = (data.get("comment") or "").strip() or None
    leave.reviewed_by = int(get_jwt_identity())
    db.session.commit()
    return jsonify(leave.to_dict())
