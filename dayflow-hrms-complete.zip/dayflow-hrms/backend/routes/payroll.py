from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt

from extensions import db
from models import Payroll, User
from auth_utils import roles_required, is_admin_or_hr

payroll_bp = Blueprint("payroll", __name__, url_prefix="/api")


@payroll_bp.get("/payroll/<int:employee_id>")
@jwt_required()
def get_payroll(employee_id):
    claims = get_jwt()
    if not is_admin_or_hr(claims) and int(get_jwt_identity()) != employee_id:
        return jsonify({"error": "You can only view your own salary details."}), 403

    User.query.get_or_404(employee_id)  # 404 if employee doesn't exist
    record = Payroll.query.filter_by(employee_id=employee_id).first()
    if not record:
        record = Payroll(employee_id=employee_id, basic_salary=0, allowances=0, deductions=0)
        db.session.add(record)
        db.session.commit()
    return jsonify(record.to_dict())


@payroll_bp.put("/payroll/<int:employee_id>")
@roles_required("admin", "hr")
def update_payroll(employee_id):
    User.query.get_or_404(employee_id)
    data = request.get_json(silent=True) or {}

    errors = {}
    for field in ("basic_salary", "allowances", "deductions"):
        if field in data:
            try:
                value = float(data[field])
                if value < 0:
                    errors[field] = "Value cannot be negative."
            except (TypeError, ValueError):
                errors[field] = "Must be a number."
    if errors:
        return jsonify({"error": "Validation failed", "fields": errors}), 400

    record = Payroll.query.filter_by(employee_id=employee_id).first()
    if not record:
        record = Payroll(employee_id=employee_id)
        db.session.add(record)

    for field in ("basic_salary", "allowances", "deductions"):
        if field in data:
            setattr(record, field, float(data[field]))
    if "pay_frequency" in data:
        record.pay_frequency = data["pay_frequency"]

    db.session.commit()
    return jsonify(record.to_dict())
