"""
Seeds the database with demo accounts and sample records so the frontend
has something to show immediately.

Run with:  python seed.py
"""
from datetime import date, timedelta, datetime

from app import create_app
from extensions import db
from models import User, Attendance, Leave, Payroll

app = create_app()

DEMO_USERS = [
    dict(employee_code="ADM001", name="Asha Rao", email="admin@dayflow.com",
         password="Admin@123", role="admin", department="Management",
         designation="HR Director", phone="9876500001"),
    dict(employee_code="HR001", name="Priya Nair", email="hr@dayflow.com",
         password="Hr@12345", role="hr", department="Human Resources",
         designation="HR Officer", phone="9876500002"),
    dict(employee_code="EMP001", name="Rohit Sharma", email="rohit@dayflow.com",
         password="Employee@123", role="employee", department="Engineering",
         designation="Frontend Developer", phone="9876500003"),
    dict(employee_code="EMP002", name="Neha Verma", email="neha@dayflow.com",
         password="Employee@123", role="employee", department="Engineering",
         designation="Backend Developer", phone="9876500004"),
    dict(employee_code="EMP003", name="Karan Mehta", email="karan@dayflow.com",
         password="Employee@123", role="employee", department="Design",
         designation="UI/UX Designer", phone="9876500005"),
]

SALARIES = {
    "ADM001": (120000, 20000, 5000),
    "HR001": (80000, 12000, 3000),
    "EMP001": (60000, 8000, 2500),
    "EMP002": (62000, 8000, 2500),
    "EMP003": (55000, 7000, 2000),
}


def run():
    with app.app_context():
        db.drop_all()
        db.create_all()

        users_by_code = {}
        for u in DEMO_USERS:
            user = User(
                employee_code=u["employee_code"],
                name=u["name"],
                email=u["email"],
                role=u["role"],
                department=u["department"],
                designation=u["designation"],
                phone=u["phone"],
                join_date=date.today() - timedelta(days=200),
            )
            user.set_password(u["password"])
            db.session.add(user)
            users_by_code[u["employee_code"]] = user

        db.session.flush()

        for code, user in users_by_code.items():
            basic, allowances, deductions = SALARIES[code]
            db.session.add(Payroll(
                employee_id=user.id, basic_salary=basic,
                allowances=allowances, deductions=deductions,
            ))

        # A week of attendance history for the three employees.
        for code in ("EMP001", "EMP002", "EMP003"):
            emp = users_by_code[code]
            for i in range(7, 0, -1):
                day = date.today() - timedelta(days=i)
                if day.weekday() >= 5:  # skip weekends
                    continue
                check_in = datetime.combine(day, datetime.min.time()) + timedelta(hours=9, minutes=5)
                check_out = check_in + timedelta(hours=8, minutes=45)
                db.session.add(Attendance(
                    employee_id=emp.id, date=day,
                    check_in=check_in, check_out=check_out, status="Present",
                ))

        # A few leave requests in different states.
        db.session.add(Leave(
            employee_id=users_by_code["EMP001"].id, leave_type="Sick",
            start_date=date.today() + timedelta(days=2),
            end_date=date.today() + timedelta(days=3),
            remarks="Fever, need rest.", status="Pending",
        ))
        db.session.add(Leave(
            employee_id=users_by_code["EMP002"].id, leave_type="Paid",
            start_date=date.today() - timedelta(days=10),
            end_date=date.today() - timedelta(days=8),
            remarks="Family function.", status="Approved",
            admin_comment="Approved, enjoy!",
        ))
        db.session.add(Leave(
            employee_id=users_by_code["EMP003"].id, leave_type="Unpaid",
            start_date=date.today() + timedelta(days=15),
            end_date=date.today() + timedelta(days=20),
            remarks="Personal travel.", status="Pending",
        ))

        db.session.commit()
        print("Seeded database with demo accounts:")
        for u in DEMO_USERS:
            print(f"  {u['role']:<9} {u['email']:<20} password: {u['password']}")


if __name__ == "__main__":
    run()
