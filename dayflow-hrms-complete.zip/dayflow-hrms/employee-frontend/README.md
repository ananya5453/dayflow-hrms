# Dayflow HRMS — Employee Frontend

React + Vite + Tailwind frontend for regular employees: profile, attendance
check-in/out, and time-off requests. Shares the same design tokens as the
Admin/HR frontend so both apps look like one product.

## Setup

```bash
npm install
cp .env.example .env      # then set VITE_API_BASE_URL to the Flask server's URL
npm run dev
```

## Pages

1. **Login** (`/login`) — email/password validation, calls `POST /api/login`.
   Only accounts with role `employee` are let in here — `admin`/`hr` accounts
   are told to use the Admin dashboard instead.
2. **Signup** (`/signup`) — `POST /api/signup`, client + server validation
   (email format, 8+ char password, matching confirm-password).
3. **My Profile** (`/`) — `GET /api/profile`. Employees can edit phone and
   address inline; everything else (name, department, role) is admin-only,
   enforced by the backend, not just hidden here. Salary section is
   explicitly read-only.
4. **Attendance** (`/attendance`) — `GET /api/attendance/<id>` for history,
   `POST /api/attendance/checkin` and `/checkout` for today. Check-in button
   disables once you've checked in; check-out disables until you have and
   again once you've already checked out.
5. **Time Off** (`/time-off`) — `GET /api/leaves` (auto-scoped to the
   logged-in employee by the backend) and `POST /api/leaves` to apply, with
   date-range and required-field validation before submit.

## Role-based access

There is no UI anywhere in this app for approving leave or editing salary —
those actions only exist in the separate Admin/HR frontend. Even if someone
tried to call those endpoints directly from this app, the backend rejects
non-admin/hr tokens with a 403.
