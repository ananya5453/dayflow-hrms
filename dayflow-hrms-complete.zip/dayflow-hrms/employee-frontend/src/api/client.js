import axios from 'axios'

// Single source of truth for the backend URL.
const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'

const client = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
})

// Attach the saved token (if any) to every request.
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('dayflow_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// If the backend ever says the token is invalid/expired, log the user out
// and send them back to the login screen.
client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && !window.location.pathname.startsWith('/login')) {
      localStorage.removeItem('dayflow_token')
      localStorage.removeItem('dayflow_user')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default client

// ---- API calls, one function per endpoint ----

export const signupRequest = (payload) => client.post('/api/signup', payload)

export const loginRequest = (email, password) =>
  client.post('/api/login', { email, password })

export const getMyProfile = () => client.get('/api/profile')

export const updateMyProfile = (employeeId, data) =>
  client.put(`/api/employees/${employeeId}`, data)

export const getMyAttendance = (employeeId) =>
  client.get(`/api/attendance/${employeeId}`)

export const checkIn = () => client.post('/api/attendance/checkin')

export const checkOut = () => client.post('/api/attendance/checkout')

export const getMyLeaves = () => client.get('/api/leaves')

export const applyForLeave = (data) => client.post('/api/leaves', data)

export const getMyPayroll = (employeeId) =>
  client.get(`/api/payroll/${employeeId}`)
