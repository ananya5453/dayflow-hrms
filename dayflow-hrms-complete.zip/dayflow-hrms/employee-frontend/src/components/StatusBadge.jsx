const STYLES = {
  Pending: 'badge-pending',
  Approved: 'badge-approved',
  Rejected: 'badge-rejected',
  Present: 'badge-approved',
  Absent: 'badge-rejected',
  'Half-day': 'badge-pending',
  Leave: 'badge-pending',
}

export default function StatusBadge({ status }) {
  return <span className={`badge ${STYLES[status] || 'bg-slate-100 text-slate-600'}`}>{status}</span>
}
