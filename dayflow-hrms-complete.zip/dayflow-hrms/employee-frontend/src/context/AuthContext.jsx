import { createContext, useContext, useState } from 'react'
import { loginRequest } from '../api/client'

const AuthContext = createContext(null)

// This app is for regular employees only. Admins/HR use the separate
// Admin/HR frontend, which is what actually approves leave and edits salary.
const ALLOWED_ROLES = ['employee']

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('dayflow_user')
    return saved ? JSON.parse(saved) : null
  })

  async function login(email, password) {
    const res = await loginRequest(email, password)
    const { token, user: loggedInUser } = res.data

    if (!ALLOWED_ROLES.includes(loggedInUser.role)) {
      throw new Error('This is the employee portal. HR/Admin should use the admin dashboard.')
    }

    localStorage.setItem('dayflow_token', token)
    localStorage.setItem('dayflow_user', JSON.stringify(loggedInUser))
    setUser(loggedInUser)
    return loggedInUser
  }

  function logout() {
    localStorage.removeItem('dayflow_token')
    localStorage.removeItem('dayflow_user')
    setUser(null)
  }

  function updateStoredUser(next) {
    localStorage.setItem('dayflow_user', JSON.stringify(next))
    setUser(next)
  }

  return (
    <AuthContext.Provider value={{ user, login, logout, updateStoredUser }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  return useContext(AuthContext)
}
