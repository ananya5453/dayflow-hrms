import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { getMyAttendance, checkIn, checkOut } from '../api/client'
import LoadingSpinner from '../components/LoadingSpinner'
import StatusBadge from '../components/StatusBadge'

function fmtTime(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

export default function Attendance() {
  const { user } = useAuth()
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [actionError, setActionError] = useState('')
  const [actionLoading, setActionLoading] = useState(false)

  const today = new Date().toISOString().slice(0, 10)
  const todayRecord = records.find((r) => r.date === today)

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    try {
      const res = await getMyAttendance(user.id)
      setRecords(res.data)
    } finally {
      setLoading(false)
    }
  }

  async function handleCheckIn() {
    setActionError('')
    setActionLoading(true)
    try {
      await checkIn()
      await load()
    } catch (err) {
      setActionError(err.response?.data?.error || 'Could not check in.')
    } finally {
      setActionLoading(false)
    }
  }

  async function handleCheckOut() {
    setActionError('')
    setActionLoading(true)
    try {
      await checkOut()
      await load()
    } catch (err) {
      setActionError(err.response?.data?.error || 'Could not check out.')
    } finally {
      setActionLoading(false)
    }
  }

  if (loading) return <LoadingSpinner />

  return (
    <div className="space-y-6">
      <div className="card flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-lg font-bold text-ink">Attendance</h1>
          <p className="text-sm text-slate-500">
            Today: {todayRecord?.check_in ? `Checked in at ${fmtTime(todayRecord.check_in)}` : 'Not checked in yet'}
            {todayRecord?.check_out ? ` · Checked out at ${fmtTime(todayRecord.check_out)}` : ''}
          </p>
        </div>
        <div className="flex gap-3">
          <button
            className="btn-approve"
            onClick={handleCheckIn}
            disabled={actionLoading || !!todayRecord?.check_in}
          >
            Check In
          </button>
          <button
            className="btn-reject"
            onClick={handleCheckOut}
            disabled={actionLoading || !todayRecord?.check_in || !!todayRecord?.check_out}
          >
            Check Out
          </button>
        </div>
      </div>

      {actionError && (
        <div className="rounded-lg bg-rose-50 text-reject text-sm px-3 py-2 border border-rose-100">
          {actionError}
        </div>
      )}

      <div className="card overflow-x-auto">
        <h2 className="font-display font-semibold text-ink mb-4">History</h2>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-slate-500 border-b border-slate-100">
              <th className="py-2 pr-4">Date</th>
              <th className="py-2 pr-4">Check In</th>
              <th className="py-2 pr-4">Check Out</th>
              <th className="py-2 pr-4">Status</th>
            </tr>
          </thead>
          <tbody>
            {records.length === 0 && (
              <tr>
                <td colSpan={4} className="py-6 text-center text-slate-400">
                  No attendance records yet.
                </td>
              </tr>
            )}
            {records.map((r) => (
              <tr key={r.id} className="border-b border-slate-50 last:border-0">
                <td className="py-2 pr-4">{r.date}</td>
                <td className="py-2 pr-4">{fmtTime(r.check_in)}</td>
                <td className="py-2 pr-4">{fmtTime(r.check_out)}</td>
                <td className="py-2 pr-4">
                  <StatusBadge status={r.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
