import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getMyProfile, updateMyProfile } from '../api/client'
import { useAuth } from '../context/AuthContext'
import LoadingSpinner from '../components/LoadingSpinner'

export default function Profile() {
  const { user, updateStoredUser } = useAuth()
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({ phone: '', address: '' })
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    setError('')
    try {
      const res = await getMyProfile()
      setProfile(res.data)
      setForm({ phone: res.data.phone || '', address: res.data.address || '' })
    } catch {
      setError('Could not load your profile.')
    } finally {
      setLoading(false)
    }
  }

  async function handleSave(e) {
    e.preventDefault()
    setSaving(true)
    try {
      const res = await updateMyProfile(user.id, form)
      setProfile((p) => ({ ...p, ...res.data }))
      updateStoredUser({ ...user, ...res.data })
      setEditing(false)
    } catch {
      setError('Could not save changes. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <LoadingSpinner />
  if (error && !profile) return <p className="text-reject">{error}</p>

  return (
    <div className="space-y-6">
      <div className="card flex items-start justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-flow/10 text-flow flex items-center justify-center text-xl font-bold">
            {profile.name?.[0]?.toUpperCase()}
          </div>
          <div>
            <h1 className="text-lg font-bold text-ink">{profile.name}</h1>
            <p className="text-sm text-slate-500">
              {profile.designation} · {profile.department}
            </p>
            <p className="text-xs text-slate-400 mt-1">Employee ID: {profile.employee_code}</p>
          </div>
        </div>
        <div className="flex gap-3">
          <Link to="/attendance" className="btn-ghost">Attendance</Link>
          <Link to="/time-off" className="btn-primary">Request Time Off</Link>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold text-ink">Personal Details</h2>
            {!editing && (
              <button className="text-sm text-flow font-medium hover:underline" onClick={() => setEditing(true)}>
                Edit
              </button>
            )}
          </div>

          {!editing ? (
            <dl className="space-y-3 text-sm">
              <Row label="Email" value={profile.email} />
              <Row label="Phone" value={profile.phone || '—'} />
              <Row label="Address" value={profile.address || '—'} />
              <Row label="Joined" value={profile.join_date} />
            </dl>
          ) : (
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="label">Phone</label>
                <input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              </div>
              <div>
                <label className="label">Address</label>
                <input className="input" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </div>
              <div className="flex gap-3">
                <button type="submit" className="btn-primary" disabled={saving}>
                  {saving ? 'Saving…' : 'Save changes'}
                </button>
                <button type="button" className="btn-ghost" onClick={() => setEditing(false)}>
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>

        <div className="card">
          <h2 className="font-display font-semibold text-ink mb-4">Salary Info</h2>
          {profile.payroll ? (
            <dl className="space-y-3 text-sm">
              <Row label="Basic salary" value={`₹${profile.payroll.basic_salary.toLocaleString()}`} />
              <Row label="Allowances" value={`₹${profile.payroll.allowances.toLocaleString()}`} />
              <Row label="Deductions" value={`₹${profile.payroll.deductions.toLocaleString()}`} />
              <Row label="Pay frequency" value={profile.payroll.pay_frequency} />
              <div className="pt-3 border-t border-slate-100 flex justify-between font-semibold text-ink">
                <span>Net pay</span>
                <span>₹{profile.payroll.net_pay.toLocaleString()}</span>
              </div>
            </dl>
          ) : (
            <p className="text-sm text-slate-400">Not available yet.</p>
          )}
          <p className="text-xs text-slate-400 mt-4">
            Salary details are read-only. Contact HR for any changes.
          </p>
        </div>
      </div>
    </div>
  )
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-ink font-medium text-right">{value}</dd>
    </div>
  )
}
