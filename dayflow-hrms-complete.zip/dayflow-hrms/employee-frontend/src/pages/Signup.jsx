import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { signupRequest } from '../api/client'

const initialForm = {
  name: '',
  employee_id: '',
  email: '',
  phone: '',
  department: '',
  designation: '',
  password: '',
  confirmPassword: '',
}

export default function Signup() {
  const navigate = useNavigate()
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [serverError, setServerError] = useState('')
  const [loading, setLoading] = useState(false)

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  function validate() {
    const e = {}
    if (!form.name.trim()) e.name = 'Full name is required.'
    if (!form.employee_id.trim()) e.employee_id = 'Employee ID is required.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email.'
    if (form.password.length < 8) e.password = 'Password must be at least 8 characters.'
    if (form.password !== form.confirmPassword) e.confirmPassword = 'Passwords do not match.'
    return e
  }

  async function handleSubmit(ev) {
    ev.preventDefault()
    setServerError('')
    const validationErrors = validate()
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    setLoading(true)
    try {
      await signupRequest({
        name: form.name,
        employee_id: form.employee_id,
        email: form.email,
        phone: form.phone,
        department: form.department,
        designation: form.designation,
        password: form.password,
        role: 'employee',
      })
      navigate('/login', { state: { justSignedUp: true } })
    } catch (err) {
      const data = err.response?.data
      if (data?.fields) setErrors(data.fields)
      setServerError(data?.error || 'Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-surface px-4 py-10">
      <div className="card w-full max-w-lg">
        <h1 className="text-xl font-bold text-ink mb-1">Create your Dayflow account</h1>
        <p className="text-sm text-slate-500 mb-6">Sign up as an employee</p>

        {serverError && (
          <div className="mb-4 rounded-lg bg-rose-50 text-reject text-sm px-3 py-2 border border-rose-100">
            {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Full name</label>
              <input className="input" value={form.name} onChange={(e) => update('name', e.target.value)} />
              {errors.name && <p className="text-xs text-reject mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="label">Employee ID</label>
              <input
                className="input"
                value={form.employee_id}
                onChange={(e) => update('employee_id', e.target.value)}
              />
              {errors.employee_id && <p className="text-xs text-reject mt-1">{errors.employee_id}</p>}
            </div>
          </div>

          <div>
            <label className="label">Email</label>
            <input
              type="email"
              className="input"
              value={form.email}
              onChange={(e) => update('email', e.target.value)}
            />
            {errors.email && <p className="text-xs text-reject mt-1">{errors.email}</p>}
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Phone</label>
              <input className="input" value={form.phone} onChange={(e) => update('phone', e.target.value)} />
            </div>
            <div>
              <label className="label">Department</label>
              <input
                className="input"
                value={form.department}
                onChange={(e) => update('department', e.target.value)}
              />
            </div>
          </div>

          <div>
            <label className="label">Designation</label>
            <input
              className="input"
              value={form.designation}
              onChange={(e) => update('designation', e.target.value)}
            />
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Password</label>
              <input
                type="password"
                className="input"
                value={form.password}
                onChange={(e) => update('password', e.target.value)}
              />
              {errors.password && <p className="text-xs text-reject mt-1">{errors.password}</p>}
            </div>
            <div>
              <label className="label">Confirm password</label>
              <input
                type="password"
                className="input"
                value={form.confirmPassword}
                onChange={(e) => update('confirmPassword', e.target.value)}
              />
              {errors.confirmPassword && (
                <p className="text-xs text-reject mt-1">{errors.confirmPassword}</p>
              )}
            </div>
          </div>

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? 'Creating account…' : 'Sign Up'}
          </button>
        </form>

        <p className="text-sm text-slate-500 mt-5 text-center">
          Already have an account?{' '}
          <Link to="/login" className="text-flow font-medium hover:underline">
            Log in
          </Link>
        </p>
      </div>
    </div>
  )
}
