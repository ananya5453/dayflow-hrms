import { useEffect, useState } from 'react'
import { getMyLeaves, applyForLeave } from '../api/client'
import LoadingSpinner from '../components/LoadingSpinner'
import StatusBadge from '../components/StatusBadge'

const LEAVE_TYPES = ['Paid', 'Sick', 'Unpaid']

const initialForm = { leave_type: 'Paid', start_date: '', end_date: '', remarks: '' }

export default function TimeOff() {
  const [leaves, setLeaves] = useState([])
  const [loading, setLoading] = useState(true)
  const [form, setForm] = useState(initialForm)
  const [errors, setErrors] = useState({})
  const [serverError, setServerError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [successMsg, setSuccessMsg] = useState('')

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    try {
      const res = await getMyLeaves()
      setLeaves(res.data)
    } finally {
      setLoading(false)
    }
  }

  function validate() {
    const e = {}
    if (!form.start_date) e.start_date = 'Start date is required.'
    if (!form.end_date) e.end_date = 'End date is required.'
    if (form.start_date && form.end_date && form.end_date < form.start_date) {
      e.end_date = 'End date cannot be before the start date.'
    }
    return e
  }

  async function handleSubmit(ev) {
    ev.preventDefault()
    setServerError('')
    setSuccessMsg('')
    const validationErrors = validate()
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    setSubmitting(true)
    try {
      await applyForLeave(form)
      setForm(initialForm)
      setSuccessMsg('Your time-off request was submitted and is pending approval.')
      await load()
    } catch (err) {
      const data = err.response?.data
      if (data?.fields) setErrors(data.fields)
      setServerError(data?.error || 'Could not submit your request.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="grid lg:grid-cols-[1fr_1.4fr] gap-6">
      <div className="card h-fit">
        <h1 className="text-lg font-bold text-ink mb-1">Request Time Off</h1>
        <p className="text-sm text-slate-500 mb-4">Paid Time Off · Sick Leave · Unpaid Leave</p>

        {successMsg && (
          <div className="mb-4 rounded-lg bg-emerald-50 text-approve text-sm px-3 py-2 border border-emerald-100">
            {successMsg}
          </div>
        )}
        {serverError && (
          <div className="mb-4 rounded-lg bg-rose-50 text-reject text-sm px-3 py-2 border border-rose-100">
            {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Time-off type</label>
            <select
              className="input"
              value={form.leave_type}
              onChange={(e) => setForm({ ...form, leave_type: e.target.value })}
            >
              {LEAVE_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Start date</label>
              <input
                type="date"
                className="input"
                value={form.start_date}
                onChange={(e) => setForm({ ...form, start_date: e.target.value })}
              />
              {errors.start_date && <p className="text-xs text-reject mt-1">{errors.start_date}</p>}
            </div>
            <div>
              <label className="label">End date</label>
              <input
                type="date"
                className="input"
                value={form.end_date}
                onChange={(e) => setForm({ ...form, end_date: e.target.value })}
              />
              {errors.end_date && <p className="text-xs text-reject mt-1">{errors.end_date}</p>}
            </div>
          </div>
          <div>
            <label className="label">Remarks</label>
            <textarea
              className="input"
              rows={3}
              value={form.remarks}
              onChange={(e) => setForm({ ...form, remarks: e.target.value })}
              placeholder="Optional note for your manager"
            />
          </div>
          <button type="submit" className="btn-primary w-full" disabled={submitting}>
            {submitting ? 'Submitting…' : 'Submit Request'}
          </button>
        </form>
      </div>

      <div className="card">
        <h2 className="font-display font-semibold text-ink mb-4">My Requests</h2>
        {loading ? (
          <LoadingSpinner />
        ) : leaves.length === 0 ? (
          <p className="text-sm text-slate-400">You haven't requested any time off yet.</p>
        ) : (
          <ul className="divide-y divide-slate-100">
            {leaves.map((l) => (
              <li key={l.id} className="py-3 flex items-start justify-between gap-4">
                <div>
                  <p className="font-medium text-ink text-sm">{l.leave_type} Leave</p>
                  <p className="text-xs text-slate-500">{l.start_date} → {l.end_date}</p>
                  {l.remarks && <p className="text-xs text-slate-400 mt-1">"{l.remarks}"</p>}
                  {l.admin_comment && (
                    <p className="text-xs text-slate-500 mt-1">HR note: {l.admin_comment}</p>
                  )}
                </div>
                <StatusBadge status={l.status} />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
